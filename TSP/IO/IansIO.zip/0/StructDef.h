/* ------------------------------------------------------------------------- */
// Project Name: 	CS325 - Project 1
// File 			Name: StructDef.h
// Desc: 			Structure definitions
// Authors:			Ian Dalrymple, Megan Fanning, Toni York
// Date: 			05/28/2016
/* ------------------------------------------------------------------------- */
#ifndef STRUCT_DEF_INCLUDED
#define STRUCT_DEF_INCLUDED 1

	struct structCity
	{
		int iId;
		int iX;
		int iY;
	};

#endif
